#include <opencv2/opencv.hpp>

using namespace cv;

// Global variables to store mouse wheel delta and keyboard input
int mouseWheelDelta = 0;
int keyboardInput = 0;

// Mouse callback function to handle mouse events
void onMouse(int event, int x, int y, int flags, void* userdata)
{
    if (event == EVENT_MOUSEWHEEL)
    {
        // Update the mouse wheel delta
        mouseWheelDelta = getMouseWheelDelta(flags);
    }
}

int main()
{
    // Create a window
    namedWindow("Game", WINDOW_AUTOSIZE);

    // Set up the field dimensions
    int fieldWidth = 800;
    int fieldHeight = 600;

    // Set up the racket dimensions
    int racketWidth = 100;
    int racketHeight = 20;

    // Set up the ball properties
    int ballRadius = 10;
    int ballSpeed = 5;
    Point ballPosition(fieldWidth / 2, fieldHeight / 2);
    Point ballDirection(1, -1);

    // Set up the racket position
    Point racketPosition((fieldWidth - racketWidth) / 2, fieldHeight - racketHeight);

    // Register the mouse callback function
    setMouseCallback("Game", onMouse);

    // Game loop
    while (true)
    {
        // Clear the field
        Mat field(fieldHeight, fieldWidth, CV_8UC3, Scalar(0, 0, 0));

        // Draw the walls
        rectangle(field, Point(0, 0), Point(fieldWidth - 1, fieldHeight - 1), Scalar(255, 255, 255), 1);

        // Draw the racket
        rectangle(field, racketPosition, Point(racketPosition.x + racketWidth, racketPosition.y + racketHeight), Scalar(255, 255, 255), -1);

        // Draw the ball
        circle(field, ballPosition, ballRadius, Scalar(255, 255, 255), -1);

        // Show the field
        imshow("Game", field);

        // Move the ball
        ballPosition += ballSpeed * ballDirection;

        // Check for collisions with walls
        if (ballPosition.x <= ballRadius || ballPosition.x >= fieldWidth - ballRadius)
            ballDirection.x *= -1;
        if (ballPosition.y <= ballRadius)
            ballDirection.y *= -1;

        // Check for collision with the racket
        if (ballPosition.y + ballRadius >= racketPosition.y && ballPosition.x >= racketPosition.x && ballPosition.x <= racketPosition.x + racketWidth)
            ballDirection.y *= -1;

        // Check if the ball falls down
        if (ballPosition.y > fieldHeight)
            break;

        // Handle keyboard input
        keyboardInput = waitKey(10);
        if (keyboardInput == 27) // ESC key
            break;

        // Handle mouse wheel input
        if (mouseWheelDelta > 0)
            racketPosition.x -= 10;
        else if (mouseWheelDelta < 0)
            racketPosition.x += 10;

        // Handle keyboard input for racket movement
        if (keyboardInput == 'a' || keyboardInput == 'A')
            racketPosition.x -= 10;
        else if (keyboardInput == 'd' || keyboardInput == 'D')
            racketPosition.x += 10;

        // Reset the mouse wheel delta
        mouseWheelDelta = 0;
    }

    // Destroy the window
    destroyWindow("Game");

    return 0;
}
